# Integrating SuperDrastic into a firmware

This is the contract between SuperDrastic and the firmware that starts DraStic: what the package contains, how it
gets the display, what it tells you, and every setting. The settings keep the `DSFLIP_` prefix from the library's
original name (libdsflip), so existing integrations keep working.

## The package

`superdrastic-<version>-aarch64.tar.gz` unpacks to one folder:

| File | |
|---|---|
| `libsuperdrastic.so` | The library, loaded into DraStic with `LD_PRELOAD` |
| `superdrastic-run` | The launcher: `superdrastic-run <drastic> [args...] <rom>` |
| `superdrastic-update` | Updates the folder from GitHub's latest release (keeps `superdrastic.conf`, `data/`, `logs/`) |
| `superdrastic.conf.example` | Every setting, commented |
| `shaders/` | The `ds-*` shaders |
| `VERSION`, `README.md`, `LICENSE`, `THIRD_PARTY.md` | |

The folder can live anywhere writable. `data/` (RetroAchievements login token, badge cache, the CPU governor's memory)
and `logs/` are created beside the launcher.

## Starting a game

Replace your DraStic command with `superdrastic-run` followed by the same command:

```sh
/opt/superdrastic/superdrastic-run /path/to/drastic --some-drastic-option /path/to/game.nds
```

The launcher gets the display from your frontend, runs DraStic with the library from DraStic's own folder (DraStic
reads its configuration from its working directory), waits for it and gives everything back. It exits with DraStic's
status: 0 when the player chose Exit in DraStic's menu, 137 when a hotkey killed it.

**Exit hotkeys** that `killall drastic` (or `kill -9` the DraStic process) keep working: DraStic still runs as its own
binary. If your hotkey matches the binary's name, keep the name `drastic` (ROCKNIX, for example, runs DraStic through
a symlink called `drastic`).

## Getting the display: `DSFLIP_HANDOVER`

Only one program can drive the panels, and SuperDrastic needs them for itself (DRM master). Pick how your frontend lets
go:

| Value | What happens | Use when |
|---|---|---|
| `auto` (default) | `cmd` if `DSFLIP_STOP_CMD` is set, else `vt` if a compositor (sway, weston, labwc, cage, gamescope, kwin, X) runs, else `none` | |
| `none` | Nothing | Your frontend is a KMS program that exits or drops the display while games run |
| `vt` | Switches the console to VT `DSFLIP_VT` (12) and back afterwards. A compositor started through seatd or logind releases the display on the switch and takes it back afterwards | Your frontend runs under a Wayland compositor with seatd/logind. The fastest way back to the menu: nothing restarts |
| `cmd` | Runs `DSFLIP_STOP_CMD` before the game and `DSFLIP_START_CMD` after it | Anything else: stop and start your frontend (and its compositor) |

Traps found on the RG DS:

- **`vt`:** the new VT must stay in text mode and unblanked, or the kernel powers the panels down under the game; the
  launcher handles both. A frontend that tears its GL context down for a game may fail to create it again after the
  switch: keep its window during games (EmulationStation: `HideWindow` off).
- **Stopping a compositor while its buffers are on screen** can leave the RK356x display controller in an underrun
  loop (tens of thousands of interrupts a second, until the next full modeset). SuperDrastic checks for it right
  after it takes the display (30 ms) and power-cycles the panels only if it's happening. If it starts when a game
  ends, switching your frontend's outputs off and on (a full modeset) clears it.

If SuperDrastic can't take the display, the launcher hands it back and starts DraStic the ordinary way
(`DSFLIP_FALLBACK=0` to give up instead).

## While a game runs

The launcher also sets, and puts back afterwards, the parts of the system that decide power use (each only where the
system has it):

- **The GPU's clock** (the first `/sys/class/devfreq/*gpu*`): its lowest with no shader (nothing is drawn on the GPU),
  `simple_ondemand` with a floor near 400 MHz with a shader, full with `ds-fsr`. Another service changing it mid-game
  (ROCKNIX's charger watcher does) gets it put back within 2 s. `DSFLIP_GPU_CLOCKS=0` leaves it alone.
- **The CPU's clock limit**: SuperDrastic's own governor lowers `scaling_max_freq` while the game needs less. It works
  only when the `performance` governor is active and the CPU is one cluster (`cpufreq/policy0` only); otherwise it
  stays off and your governor decides. The launcher lifts the limit the moment DraStic exits. `DSFLIP_CPUGOV=0`
  turns the governor off. A clock that dropped frames is remembered per game, shader and resolution
  (`data/cpugov/`), so the next session doesn't find it again by dropping frames; two minutes at it without a drop
  forgive it. `DSFLIP_CPUGOV_MEMORY=0` starts every session knowing nothing. While DraStic saves or loads a state
  (its save/load button, or a savestate file opened) the clock goes to the CPU's top for a few seconds, then back:
  DraStic does that work on its main thread, and at a low clock the game stalled visibly.
- **PipeWire's rate**, set to DraStic's 44.1 kHz (`clock.force-rate`) so it doesn't resample every cycle, and put back
  afterwards. Set before DraStic opens its audio: switching mid-stream makes the audio timing uneven.
  `DSFLIP_AUDIO_RATE=0` leaves it alone.

## Quitting with a save (resume)

Exit hotkeys usually kill DraStic (`kill -9`), which loses the game's place. Send it **SIGUSR1** instead and set
`DSFLIP_RESUME_FILE`: SuperDrastic presses DraStic's own "save state" control (the joystick button `drastic.cfg`
maps to it), writes the savestate to that file instead of one of the player's slots, and exits with SIGKILL (status
137, as a hotkey kill). Measured on the RG DS: ~0.8 s for the save. A second SIGUSR1, or no savestate within 5 s,
exits at once. Start the game next time with `DSFLIP_RESUME_LOAD=1` as well: once it runs, SuperDrastic presses
"load state" with DraStic's lookup pointed at the resume file, shows a "Resumed" pop-up and deletes the file.

Keep the file in DraStic's `savestates/` folder (a rename, no copy) and name it anything but `<game>_<digit>.dss`.
With DraStic's `backup_in_savestates` on (its default), loading a state also puts back the in-game save it was taken
with: don't load a resume state older than the game's `.dsv` (ROCKNIXDS drops it then). On ROCKNIX the hotkey runs
`killall $(cat /tmp/.process-kill-data)`, so writing `-USR1 drastic` there after `start_drastic.sh` has set it is enough.

**Exit combos.** Holding **Start + Select** or **Menu + Start** for 0.3 seconds quits the same way (with a resume
save when `DSFLIP_RESUME_FILE` is set, else at once), like ROCKNIX's gptokeyb did for DraStic. The buttons are the
ones `drastic.cfg` maps to `START`, `SELECT` and `MENU` (either control set). `DSFLIP_EXIT_COMBO=0` turns them off.

## The in-game menu

DraStic's menu button (the controls `drastic.cfg` maps to `MENU`, L3 and the mode key on the RG DS) opens
SuperDrastic's own menu instead of DraStic's (`src/menu.c`), drawn in ROCKNIXDS Pixel's look with the theme's font and
sounds when the theme is installed. The game, its sound and its clock stop while it is open. Bottom screen: Resume,
Save and Load, Quick settings, DraStic's own menu (cheats, controls, firmware) and Quit (with a resume save when that
is on). Top screen: the game, this session's play time, the last save and the latest RetroAchievements unlocks with
their badges. D-pad, left stick and touch all work. `DSFLIP_MENU=0` brings back DraStic's menu. The exit hotkey also
works while the menu is open. The pop-ups on the top screen (achievements, volume, saves) use the same look.

- **Save and Load**: 8 slots with the picture each savestate holds (DraStic keeps both screens in it: **L / R** switch
  every picture between the top and the bottom screen). "LAST" marks the slot saved to this session, else the newest
  file. Saves and loads press DraStic's own save/load state controls, so those must be joystick buttons. A load first
  saves the game to `/tmp/dsflip-undo.dss`, which **Y on the Load page** ("Undo last load") puts back. The menu
  doesn't open while the resume state is going in at a game's start (2-4.5 s in).
- **Quick settings** (the page scrolls): volume; brightness, one slider per screen where the device has a backlight
  per panel (ROCKNIX's `brightness set <n> <pct>`; the top panel is the screen numbered like `DSFLIP_TOP`'s connector,
  DSI-2 = screen 2, or `DSFLIP_BACKLIGHT_TOP`), else one for both; Microphone (a live meter of the real mic against
  ES's sensitivity, and a fake blow of 1, 3 or 10 s); Shader; Performance (an overlay: Off, FPS, Detailed with frame
  time and drops, Advanced with the CPU and GPU clocks and the internal resolution); Menu sounds; Tips.
- **Shader**: Off, ROCKNIX's built-in shaders (when `/usr/lib/libdrastouch.so` is there) and every `.frag` in the
  shader folders. In a session that started with a shader the new one is used as the menu closes, if it draws into
  buffers of the same size (`dsflip-output:`); otherwise (a session without a shader, or ds-fsr's 3x on the RG DS
  Plus) from the next start of the game, and a pop-up says so. "Off" in a session with a shader is a plain copy
  until the next start. The GPU's clock is the launcher's (below), so it follows the shader the session started with.
- **Tips** are the tutorial pop-ups: "Resumed where you left off" and the undo tip after a load, each shown the first
  three times only.

**The menu's settings** live in `<DSFLIP_DATA>/menu.cfg`, one `key=value` a line:

| Key | |
|---|---|
| `sounds`, `hints` | `<0 or 1> <the environment's DSFLIP_MENU_SOUNDS / DSFLIP_MENU_HINTS when it was set>` |
| `shader.<game>` | `<picked> <the shader the session had when it was picked>` (`none` for none); `<game>` is the ROM's file name without its extension |
| `perf` | the overlay: 0 off, 1 FPS, 2 detailed, 3 advanced |
| `preview` | 1: the slot pictures show the bottom screen |
| `seen.resumed`, `seen.undo` | how often a tip was shown |

Precedence: `DSFLIP_MENU_SOUNDS` and `DSFLIP_MENU_HINTS` (default 1) are the starting values. Switching one in the menu
holds until the environment's value changes (the frontend's own setting was changed after it); then the environment
wins again. The per-game shader works the same way: the pick holds while the frontend still asks for the shader it was
picked over (`DSFLIP_SHADER`, else `DSHOOK_SHADER`; `bilinear` counts as `none`).

**A launcher that sets the GPU's clock by the shader** should resolve the per-game pick the same way before it does,
or a game picked to ds-fsr in the menu would run it at the clock for no shader. `superdrastic-run` does:

```sh
G=$(basename "$ROM"); G=${G%.*}; B=$SHADER; [ "$B" = bilinear ] && B=none
PICK=$(awk -v k="shader.$G=" 'index($0, k) == 1 { v = substr($0, length(k) + 1) } END { print v }' "$DSFLIP_DATA/menu.cfg" 2>/dev/null)
[ -n "$PICK" ] && [ "${PICK#* }" = "$B" ] && SHADER=${PICK%% *}
```

## DraStic's menu

Opening DraStic's menu with `DSFLIP_MENU=0` shows a card on the top screen with the time and the battery (red at 15% or
less, unless charging) for 3 seconds. `DSFLIP_STATUS_CARD=0` turns it off. Opened from the in-game menu, whose top
screen had both already, it doesn't.

## The volume keys

While a game runs, the volume keys' indicator (the frontend's notifications are down with its compositor) shows the
volume, or the brightness when ROCKNIX's function key (the gamepad's `BTN_MODE`, Menu on the RG DS) is held or the
brightness is what changed, from `system.cfg`. The CPU runs at its top clock while the keys are in use: ROCKNIX runs
its volume script in new processes for every step, which the governor doesn't see.

## What SuperDrastic tells you

- **The verdict file**, `DSFLIP_STATE` (default `/tmp/superdrastic-state`): `ready` once SuperDrastic has both panels,
  or `passthrough: <reason>` when it gives up (DraStic then keeps running but draws nothing). It decides within ~6 s:
  up to 3 s waiting for the display, up to 3 s for a shader. Delete the file before starting DraStic.
- **The log**, `DSFLIP_LOG` (default `logs/superdrastic.log`): one per session, the previous three kept as `.1`..`.3`.
  Frame pacing, drops, the shader, audio, the CPU governor and RetroAchievements. `logs/run.log` is the launcher's
  own.

## Settings

Environment variables, or `superdrastic.conf` beside the launcher (a value there wins over the environment).

| Variable | Default | |
|---|---|---|
| `SDL_VIDEODRIVER` | `dummy` (set by the launcher) | Required: SDL must not open a window or the display |
| `DSFLIP_HANDOVER`, `DSFLIP_VT`, `DSFLIP_STOP_CMD`, `DSFLIP_START_CMD` | `auto` | See *Getting the display* |
| `DSFLIP_DRASTIC_DIR` | DraStic's own folder | Where DraStic runs (and reads its configuration) |
| `DSFLIP_SHADER` | none | A shader by name, e.g. `ds-crisp`; none = DraStic's frames go straight to the panels |
| `DSFLIP_SHADER_DIR` | | Another folder of `.frag` shaders (checked first) |
| `DSFLIP_SHADER_OUTPUT` | the shader's own line | The size of the buffer the shader draws into: `3x` (the DS screen times 3, 768x576), `WxH`, or `panel`; see *Shaders* |
| `DSFLIP_CARD` | the first `/dev/dri/card*` with two connected DSI panels | The display device |
| `DSFLIP_TOP` | `DSI-2` | The connector that shows the DS top screen |
| `DSFLIP_TOUCH` | `fe5e0000.i2c` | A fragment of the bottom touchscreen's device path |
| `DSFLIP_TOUCH_INVERT` | none | `x`, `y` or `xy` |
| `DSFLIP_DATA` | `data/` beside the launcher | RetroAchievements login token and badge cache |
| `DSFLIP_RA_USER`, `DSFLIP_RA_PASSWORD` | | RetroAchievements account; the password is used once, then the token |
| `DSFLIP_RA_SOUND` | none | An `.ogg` played on unlocks |
| `DSFLIP_FONT` | DejaVu Sans / Liberation Sans | Font for the pop-ups (TTF/OTF) |
| `DSHOOK_MIC_THRESH` | 0 (off) | Microphone sensitivity: 0.03 high, 0.15 medium, 0.3 low. The mic is opened after DraStic's audio output, never at the same time |
| `DSFLIP_EXIT_COMBO`, `DSFLIP_STATUS_CARD` | 1, 1 | 0 = no Start+Select / Menu+Start exit; no time and battery card in DraStic's menu |
| `DSFLIP_MENU` | 1 | 0 = the menu button opens DraStic's own menu instead of the in-game menu |
| `DSFLIP_MENU_SOUNDS`, `DSFLIP_MENU_HINTS` | 1, 1 | The in-game menu's navigation sounds and its tips, until switched in the menu (see *The in-game menu*). ROCKNIXDS sets the sounds from ES's navigation sounds |
| `DSFLIP_BACKLIGHT_TOP` | from `DSFLIP_TOP` | ROCKNIX's screen number (1 or 2) of the top panel's backlight, for the menu's per-screen brightness |
| `DSFLIP_MIC_HOLD_MS` | 120 | Once a blow presses the fake microphone, it stays down at least this long (see `src/audio.c` for the other mic tunables) |
| `DSFLIP_CPUGOV`, `DSFLIP_CPU_MIN`, `DSFLIP_CPU_MAX` | on, 1104 MHz, the CPU's top | The CPU governor and its bounds (kHz). A `DSFLIP_CPU_MAX` below the top holds from the first moment |
| `DSFLIP_CPU_MAX_SOFT` | 0 | 1 = `DSFLIP_CPU_MAX` is passed while the game is below full speed with real work going on (for a "balanced" profile: a heavy game gets the clock it needs instead of running slow at the bound) |
| `DSFLIP_CPUGOV_MEMORY` | 1 | 0 = the governor doesn't remember clocks that dropped frames |
| `DSFLIP_QUEUE` | 1 | Frames that may wait behind the next one, 0-3 (0 = newest only). Each is a refresh (16.7 ms) of input latency, and covers one late frame |
| `DSFLIP_QUEUE_WAIT` | 0 (off) | Milliseconds DraStic is held when the queue is full, instead of dropping a frame (20 works; for capped clocks) |
| `DSFLIP_LATCH_MARGIN` | 1300 | The shortest time (µs) before a vblank that a frame is committed at (diagnostics) |
| `DSFLIP_RESUME_FILE`, `DSFLIP_RESUME_LOAD` | | See *Quitting with a save* |
| `DSFLIP_STALL_QUIT` | 20 | Seconds without a frame from DraStic (outside its menu and the in-game menu) before the game is ended; 0 = never. After 5 s the log lists every thread's state and a card says so, and the exit hotkey quits at once |
| `DSFLIP_STALL_TEST` | off | Seconds after the first frame at which DraStic's main thread stops for good (tests the stall watch) |
| `DSFLIP_NOTICE` | `/tmp/dsflip-notice` | Where that ending leaves a line for the launcher to show |
| `DSFLIP_SPREAD_THREADS` | 1 | 0 = new threads inherit their creator's CPUs (with DraStic's main thread confined to one CPU, its new helper threads then share that CPU only) |
| `DSFLIP_HELPER_DOOR` | 1 | 0 = DraStic's four helper threads start the way DraStic starts them: before the locks they wait on exist. DraStic r2.5.2.2 calls `pthread_create` first and initialises the thread's two mutexes and two condition variables after it; a helper that is already waiting by then never gets its first hand-off, and the game shows no frame (or stops at its first 3D frame). With the door a helper waits for its creator's second `pthread_cond_init`, 2 s at most; the log has a line per helper |
| `DSFLIP_HELPER_RACE` | off | Milliseconds DraStic's main thread sleeps right after starting each of those helpers. With `DSFLIP_HELPER_DOOR=0` the game then freezes at every start; with the door nothing changes (tests the door on a handheld) |
| `DSFLIP_GPU_CLOCKS`, `DSFLIP_AUDIO_RATE` | 1, 1 | The launcher's GPU clock and PipeWire rate handling |
| `DSFLIP_WFC` | off | Nintendo WFC online play (parked: it does not get past the game's Wi-Fi setup yet): `kaeru`, `altwfc`, `wiilink` or a dotted DNS address. SuperDrastic answers the DS as an open access point named `rocknixds` and hands it that DNS server over DHCP; the game's traffic goes through the host's own sockets (UDP, client TCP). Needs the DraStic build r2.5.2.2 (it checks the build id). `nds.wfc_dns` in ROCKNIX's `system.cfg` is read only with `DSFLIP_WFC_CONFIG=1`. `DSFLIP_WFC_DEBUG=1` logs every frame |
| `DSFLIP_AUDIO_PUMP` | 1 | 0 = DraStic's own SDL audio |
| `DSFLIP_AUDIO_DEVICE_RATE` | DraStic's rate (44100) | The rate (Hz) the sound device is opened at; SuperDrastic resamples to it. For a sound server that runs at another rate and can't be switched (RG DS Plus: PipeWire at 48000), where the server would otherwise resample inside the game's process |
| `DSFLIP_AUDIO_LOCK` | off | Experimental: the panels' refresh rate in Hz (the log's `[pace] period`, e.g. `60.00492`). The game then runs at that frame rate instead of the DS's 59.83 (0.3% fast, sound resampled to match), which removes the repeated frame every ~6 s that the two rates beat out |
| `DSFLIP_COLORS` | | A file with a colour correction per screen (gains, gamma, brightness, black level), set as the panels' lookup tables; see `colors_apply` in `src/dsflip.c` |
| `DSFLIP_DIRECT` | 1 | 0 = DraStic's frames are copied into the scanout buffers (as before 0.6) instead of drawn in them |
| `DSFLIP_SHADER_COPY` | 0 | 1 = upload DraStic's frames to the GPU instead of importing them |
| `DSFLIP_FALLBACK` | 1 | 0 = don't run DraStic without SuperDrastic when it can't take the display |

**Shaders** are GLSL ES 1.0 fragment shaders with the inputs DraStic's stock shaders use (`u_texture`,
`u_texture_size`, `u_output_size`, `v_texcoord`; see the top of `src/shader.c`). A shader that draws the DS screen
into part of the panel declares where (`// dsflip-viewport: x y w h`), and touch follows it. A shader may draw into
a buffer smaller than the panel and leave the rest of the scaling to the display controller (`// dsflip-output: 3x`:
three times the DS screen's 256x192, or `WxH`; never larger than the panel, and the panel itself where that doesn't
fit): `ds-fsr` does, so on 1024x768 panels it upscales a 2x game to 3x and the scaler does the last step, at about
half the GPU time of a panel-sized pass. `DSFLIP_SHADER_OUTPUT` (the same syntax, or `panel`) overrides the
shader's line. On ROCKNIX, its built-in DraStic shaders (lcd3x, sharp-bilinear and the rest) are found in its
`libdrastouch.so` by name.

## Examples

- **ROCKNIX:** [ROCKNIXDS](https://github.com/JorreFog/ROCKNIXDS) is the full integration (EmulationStation, sway,
  play stats, a DSi-style theme). Doing it by hand: ROCKNIX runs `/storage/.config/drastic/drastic` for DS games,
  from inside EmulationStation's own service, so a launcher that stops EmulationStation would stop itself. Start
  it in its own unit instead, and let it stop and start the frontend:

  ```sh
  #!/bin/sh
  # /storage/.config/drastic/drastic, with the real binary moved to drastic.real and a link to it named "drastic"
  # (mkdir -p /storage/.config/drastic/sd && ln -s ../drastic.real /storage/.config/drastic/sd/drastic)
  systemd-run --unit=superdrastic --collect -E XDG_RUNTIME_DIR=/var/run/0-runtime-dir \
      -E DSFLIP_HANDOVER=cmd -E DSFLIP_STOP_CMD="systemctl stop essway sway" \
      -E DSFLIP_START_CMD="systemctl start sway essway" -E DSHOOK_SHADER="$DSHOOK_SHADER" \
      -E DSFLIP_DRASTIC_DIR=/storage/.config/drastic \
      /storage/superdrastic/superdrastic-run /storage/.config/drastic/sd/drastic "$@" &&
  exec sleep 86400      # EmulationStation waits here until the unit stops it
  ```

  `XDG_RUNTIME_DIR` is what DraStic's audio (ALSA through PipeWire) and the launcher's PipeWire rate need; a systemd
  unit doesn't have it. The link makes the process's name `drastic`, which ROCKNIX's exit hotkey kills, while
  `DSFLIP_DRASTIC_DIR` keeps DraStic reading its configuration from its own folder.
- **A frontend under a seatd/logind Wayland compositor:** the default `vt` handover, with the frontend's window kept
  during games.
- **A frontend that is itself a KMS program** and quits (or releases the display) while a game runs: `none`.

## Problems

Look at `logs/superdrastic.log` first, then open an issue at https://github.com/JorreFog/SuperDrastic/issues with it
attached and your device's and firmware's name and version.
